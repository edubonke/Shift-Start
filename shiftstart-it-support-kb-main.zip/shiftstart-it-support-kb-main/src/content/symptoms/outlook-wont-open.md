---
title: "Outlook will not open"
slug: outlook-wont-open
description: "Outlook closes immediately, hangs at startup or displays a startup error."
content_type: symptom
category: Microsoft 365
severity: medium
tags: [outlook, crash]
related_procedures: [outlook-crashes]
related_causes: [outlook-addin]
---
Record the Office build and whether Outlook opens in safe mode.
