---
title: "Printer appears offline"
slug: printer-offline-symptom
description: "Jobs remain queued and Windows reports that the printer is offline."
content_type: symptom
category: Printing
severity: low
tags: [printer, queue]
related_procedures: [printer-offline]
related_causes: [stuck-print-queue]
---
Check whether all users are affected before changing the local queue.
