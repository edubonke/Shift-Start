---
title: "Computer is unusually slow"
slug: slow-computer
description: "The entire device or multiple applications respond more slowly than normal."
content_type: symptom
category: Desktop
severity: medium
tags: [performance, slow]
related_procedures: [slow-windows-pc]
related_causes: [resource-pressure]
---
Determine whether the issue follows the device, user profile or one application.
