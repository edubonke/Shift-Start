---
title: "Microphone is not detected in Teams"
slug: microphone-fails
description: "The user can hear others but cannot send audio in a meeting or test call."
content_type: symptom
category: Collaboration
severity: medium
tags: [teams, microphone]
related_procedures: [teams-microphone-not-working]
related_causes: [wrong-audio-device]
---
Test the microphone outside Teams to separate application and device causes.
